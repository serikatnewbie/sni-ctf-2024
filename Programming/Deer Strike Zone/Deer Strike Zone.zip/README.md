# Lomba Rusa
## Desc
Flag: SNI{hex(output)}

Contoh: SNI{deadbeef}, SNI{7}

## Attachment
- `Deer Strike Zone.pdf`
- `testcase.in`

## Flag
- `SNI{b6097ca4013d553ae0cf46edebf51bc68}`